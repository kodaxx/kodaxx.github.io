

//var sfpm = surfaceSpeed("face", "aluminum");
//var hssHigh = sfpm.hss[1];
//var hssLow = sfpm.hss[0];
//var carbideHigh = sfpm.carbide[1];
//var carbideLow = sfpm.carbide[0]
//For Drilling operation only - accessing angle
//var angleHigh = sfpm.angle[1];
//var angleLow = sfpm.angle[0];
//console.log("SFPM of HSS: " + hssLow + ", " + hssHigh + " SFPM of Carbide: " + carbideLow + ", " + carbideHigh);